#include "module_api.h"

#include <ctype.h>
#include <stdio.h>
#include <string.h>

static const GSNativeAPI *api;

static GSValue test_g_version(GSValue *args, size_t count) {
    (void)args;
    (void)count;
    return api->string("1.0.0");
}

static GSValue test_g_greet(GSValue *args, size_t count) {
    const char *name = count > 0 ? api->cstring(args[0]) : NULL;
    if (!name || !*name) name = "greenServeFE developer";

    char message[512];
    int written = snprintf(message, sizeof(message), "Hello, %s!", name);
    if (written < 0 || (size_t)written >= sizeof(message)) return api->null();
    return api->string(message);
}

static GSValue test_g_add(GSValue *args, size_t count) {
    if (count < 2) return api->null();
    double total = 0.0;

    for (size_t i = 0; i < count; ++i) {
        if (args[i].type != V_NUMBER) return api->null();
        total += api->number_value(args[i]);
    }
    return api->number(total);
}

static GSValue test_g_multiply(GSValue *args, size_t count) {
    if (count < 2) return api->null();
    double product = 1.0;

    for (size_t i = 0; i < count; ++i) {
        if (args[i].type != V_NUMBER) return api->null();
        product *= api->number_value(args[i]);
    }
    return api->number(product);
}

static GSValue test_g_upper(GSValue *args, size_t count) {
    if (count < 1 || args[0].type != V_STRING) return api->null();

    const char *input = api->cstring(args[0]);
    if (!input) return api->null();

    size_t length = strlen(input);
    char buffer[1024];
    if (length >= sizeof(buffer)) return api->null();

    for (size_t i = 0; i < length; ++i) {
        buffer[i] = (char)toupper((unsigned char)input[i]);
    }
    buffer[length] = '\0';
    return api->string(buffer);
}

GSValue greenServeFE_module_init(const GSNativeAPI *native_api) {
    if (!native_api || native_api->abi_version != GSFE_MODULE_ABI_VERSION) {
        return native_api && native_api->null
            ? native_api->null()
            : (GSValue){0};
    }

    api = native_api;
    GSValue exports = api->object();

    GSValue fn = api->native(test_g_version);
    api->object_set(&exports, "version", fn);
    api->release(fn);

    fn = api->native(test_g_greet);
    api->object_set(&exports, "greet", fn);
    api->release(fn);

    fn = api->native(test_g_add);
    api->object_set(&exports, "add", fn);
    api->release(fn);

    fn = api->native(test_g_multiply);
    api->object_set(&exports, "multiply", fn);
    api->release(fn);

    fn = api->native(test_g_upper);
    api->object_set(&exports, "upper", fn);
    api->release(fn);

    return exports;
}
