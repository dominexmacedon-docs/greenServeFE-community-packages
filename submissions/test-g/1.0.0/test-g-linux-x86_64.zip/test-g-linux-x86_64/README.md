# test-g Native Module

Linux x86_64 example native module for greenServeFE Native API ABI 1.

## Contents

- `test-g.c` — C source code.
- `module_api.h` — public native module ABI header from the greenServeFE SDK.
- `test_g.so` — compiled shared library.
- `test-g.gsve` — greenServeFE integration test.

## Exports

- `version()`
- `greet(name)`
- `add(numbers...)`
- `multiply(numbers...)`
- `upper(text)`

## Run

Place `test_g.so` in a module directory and run:

```sh
GREENSERVE_MODULE_PATH="$PWD" greenServeFE test-g.gsve
```

The shared library was built for Linux x86_64 and requires a compatible
greenServeFE runtime with Native Module ABI version 1.
