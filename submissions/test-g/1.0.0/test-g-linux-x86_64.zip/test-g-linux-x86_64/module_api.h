#ifndef GREENSERVEFE_MODULE_API_H
#define GREENSERVEFE_MODULE_API_H

/*
 * greenServeFE Native Module SDK
 * ABI: 1
 *
 * This header describes the public binary interface used by native modules.
 * It intentionally keeps VM implementation structures opaque.
 */

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#define GSFE_MODULE_ABI_VERSION 1u
#define GSFE_MODULE_INIT_SYMBOL "greenServeFE_module_init"

typedef struct GSArray GSArray;
typedef struct GSObject GSObject;
typedef struct GSEnvironment GSEnvironment;
typedef struct GSCode GSCode;
typedef struct GSIterator GSIterator;

typedef enum {
    V_NULL,
    V_NUMBER,
    V_BOOL,
    V_STRING,
    V_ARRAY,
    V_OBJECT,
    V_FUNCTION,
    V_NATIVE,
    V_ITER
} GSValueType;

typedef struct GSValue GSValue;
typedef GSValue (*GSNativeFn)(GSValue *arguments, size_t argument_count);

struct GSValue {
    GSValueType type;
    union {
        double number;
        int boolean;
        struct {
            char *data;
            size_t refs;
        } string;
        GSArray *array;
        GSObject *object;
        struct {
            GSCode *code;
            GSEnvironment *closure;
        } function;
        GSNativeFn native;
        GSIterator *iter;
    } as;
};

/*
 * All functions in this table are supplied by the greenServeFE VM.
 * Modules must use these callbacks for GSValue operations rather than
 * allocating or editing value internals themselves.
 */
typedef struct GSNativeAPI {
    uint32_t abi_version;

    GSValue (*null)(void);
    GSValue (*number)(double);
    GSValue (*boolean)(int);
    GSValue (*string)(const char *);
    GSValue (*object)(void);
    GSValue (*array)(void);
    GSValue (*native)(GSNativeFn);

    GSValue (*copy)(GSValue);
    void (*retain)(GSValue);
    void (*release)(GSValue);

    void (*array_push)(GSValue *, GSValue);
    size_t (*array_count)(GSValue);
    GSValue (*array_get)(GSValue, size_t);
    int (*array_set)(GSValue *, size_t, GSValue);

    size_t (*object_count)(GSValue);
    const char *(*object_key)(GSValue, size_t);
    void (*object_set)(GSValue *, const char *, GSValue);
    GSValue (*object_get)(GSValue, const char *);

    const char *(*cstring)(GSValue);
    int (*truthy)(GSValue);
    double (*number_value)(GSValue);
    void (*print)(FILE *, GSValue);

    void *context;
    int (*call)(void *, GSValue, GSValue *, size_t, GSValue *);
} GSNativeAPI;

typedef GSValue (*GSModuleInit)(const GSNativeAPI *api);

/*
 * Every loadable module must export this exact entry point:
 *
 *     GSValue greenServeFE_module_init(const GSNativeAPI *api);
 *
 * It must return a V_OBJECT containing the module's exported functions.
 */
GSValue greenServeFE_module_init(const GSNativeAPI *api);

#ifdef __cplusplus
}
#endif

#endif
